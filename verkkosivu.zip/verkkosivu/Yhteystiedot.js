document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    alert('Lomake lähetetty onnistuneesti!');
    
});